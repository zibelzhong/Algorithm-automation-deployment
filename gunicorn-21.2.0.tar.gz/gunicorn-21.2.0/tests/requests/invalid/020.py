from gunicorn.config import Config
from gunicorn.http.errors import InvalidHeaderName

cfg = Config()
request = InvalidHeaderName
