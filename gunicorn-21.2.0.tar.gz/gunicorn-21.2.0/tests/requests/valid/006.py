request = {
    "method": "GET",
    "uri": uri("/get_no_headers_no_body/world"),
    "version": (1, 1),
    "headers": [],
    "body": b""
}
